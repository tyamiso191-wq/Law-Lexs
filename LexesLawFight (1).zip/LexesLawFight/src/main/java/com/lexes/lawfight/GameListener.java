package com.lexes.lawfight;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.UUID;

public class GameListener implements Listener {

    private final LexesLawFight plugin;

    public GameListener(LexesLawFight plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            Location sp = plugin.getLoc("lobby");   // /spaw: girince herkes burada dogar
            if (sp != null) p.teleport(sp);
            Game g = plugin.getGame(p.getWorld());
            if (g != null) g.onJoin(p);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Game g = plugin.getGame(e.getPlayer().getWorld());
        if (g != null) g.onLeave(e.getPlayer());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        Game from = plugin.getGame(e.getFrom());
        if (from != null) from.onLeave(p);
        Bukkit.getScheduler().runTask(plugin, () -> {
            Game to = plugin.getGame(p.getWorld());
            if (to != null && p.isOnline()) to.onJoin(p);
        });
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Game g = plugin.getGame(p.getWorld());
        if (g == null) return;

        // Savas disinda kimse hasar almaz
        if (g.getState() != Game.State.RUNNING) {
            e.setCancelled(true);
            return;
        }
        if (!g.isAlive(p)) return;
        if (p.getHealth() - e.getFinalDamage() > 0) return;
        if (p.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || p.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING) return;

        e.setCancelled(true);
        g.eliminate(p, killer(e), false);
    }

    private Player killer(EntityDamageEvent e) {
        if (e instanceof EntityDamageByEntityEvent by) {
            Entity d = by.getDamager();
            if (d instanceof Player pl) return pl;
            if (d instanceof Projectile pr && pr.getShooter() instanceof Player sh) return sh;
        }
        return null;
    }

    /** Yedek: hasar olayi disinda olen oyuncular (ornegin setHealth(0)). */
    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        Game g = plugin.getGame(p.getWorld());
        if (g == null || !g.isAlive(p)) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        e.deathMessage(null);
        g.eliminate(p, p.getKiller(), true);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        for (Game g : plugin.allGames()) {
            if (g.takePending(id)) {
                e.setRespawnLocation(g.arenaSpawn());
                Bukkit.getScheduler().runTask(plugin, () -> g.toSpectator(p));
                return;
            }
        }
        Location sp = plugin.getLoc("lobby");       // normal olumlerden sonra da /spaw
        if (sp != null) e.setRespawnLocation(sp);
    }

    /** Ayardan acilirsa hazirlik suresinde oyuncular yerinden oynayamaz. */
    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!plugin.getConfig().getBoolean("freeze-during-prep", false)) return;
        Location f = e.getFrom();
        Location t = e.getTo();
        if (t == null) return;
        if (f.getX() == t.getX() && f.getZ() == t.getZ()) return;
        Game g = plugin.getGame(e.getPlayer().getWorld());
        if (g == null || g.getState() != Game.State.PREP || !g.isAlive(e.getPlayer())) return;
        Location n = f.clone();
        n.setYaw(t.getYaw());
        n.setPitch(t.getPitch());
        e.setTo(n);
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Game g = plugin.getGame(p.getWorld());
        if (g != null && g.getState() != Game.State.RUNNING) e.setCancelled(true);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (protectedFor(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (protectedFor(e.getPlayer())) e.setCancelled(true);
    }

    private boolean protectedFor(Player p) {
        if (!plugin.getConfig().getBoolean("protect-blocks", true)) return false;
        if (p.getGameMode() == GameMode.CREATIVE) return false;
        World w = p.getWorld();
        return plugin.getGame(w) != null;
    }
}
