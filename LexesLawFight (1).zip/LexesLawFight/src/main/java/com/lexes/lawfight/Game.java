package com.lexes.lawfight;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.*;

/** Tek bir Law Fight dunyasinin (arena) oyun mantigi. */
public class Game {

    public enum State { WAITING, COUNTDOWN, SELECTING, PREP, RUNNING, ENDING }

    private static final String[] ROLES = {"Flamefrags", "Wemmbu", "ManePear", "Misoty"};
    private static final String[] ROLE_KEYS = {"flame", "wemmbu", "pear", "misoty"};
    private static final String[] ARMIES = {"LAW", "MAFIA", "CINDERCREST", "NORTHERN COUNCIL"};
    private static final String[] ARMY_KEYS = {"law", "mafia", "cindercrest", "northerncouncil"};

    private final LexesLawFight plugin;
    private final String worldName;
    private final Random rnd = new Random();

    private State state = State.WAITING;
    private final List<BukkitTask> tasks = new ArrayList<>();

    private UUID hero, captain;
    private String heroName = "";
    private int roleIdx, armyIdx;
    private final Set<UUID> alive = new HashSet<>();      // ana karakter + yasayan askerler
    private final Set<UUID> soldiers = new HashSet<>();   // yasayan askerler (kaptan dahil)
    private final Set<UUID> pendingSpectator = new HashSet<>();

    public Game(LexesLawFight plugin, String worldName) {
        this.plugin = plugin;
        this.worldName = worldName;
    }

    // ------------------------------------------------------------ yardimcilar

    public State getState() { return state; }

    public boolean isAlive(Player p) { return alive.contains(p.getUniqueId()); }

    public boolean takePending(UUID id) { return pendingSpectator.remove(id); }

    private World world() { return Bukkit.getWorld(worldName); }

    private int min() { return plugin.getConfig().getInt("min-players", 8); }

    private List<Player> everyone() {
        World w = world();
        return w == null ? new ArrayList<>() : new ArrayList<>(w.getPlayers());
    }

    /** Oyuna katilabilecek oyuncular (creative ve izleyiciler haric). */
    private List<Player> participants() {
        List<Player> list = new ArrayList<>();
        for (Player p : everyone()) {
            if (p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR) list.add(p);
        }
        return list;
    }

    public Location arenaSpawn() {
        Location l = plugin.getLoc("spawn." + worldName);
        return l != null ? l : world().getSpawnLocation();
    }

    private Location heroSpawn() {
        Location l = plugin.getLoc("hero." + worldName);
        return l != null ? l : arenaSpawn();
    }

    private Location armySpawn() {
        Location l = plugin.getLoc("army." + worldName);
        return l != null ? l : arenaSpawn();
    }

    private void broadcast(String s) {
        Component c = LexesLawFight.c(s);
        for (Player p : everyone()) p.sendMessage(c);
    }

    private void title(Player p, String main, String sub, int in, int stay, int out) {
        p.showTitle(Title.title(LexesLawFight.c(main), LexesLawFight.c(sub),
                Title.Times.times(Duration.ofMillis(in * 50L), Duration.ofMillis(stay * 50L),
                        Duration.ofMillis(out * 50L))));
    }

    private void titleAll(String main, String sub, int in, int stay, int out) {
        for (Player p : everyone()) title(p, main, sub, in, stay, out);
    }

    private void soundAll(Sound s, float vol, float pitch) {
        for (Player p : everyone()) p.playSound(p.getLocation(), s, vol, pitch);
    }

    private void track(BukkitTask t) { tasks.add(t); }

    public void cancelTasks() {
        for (BukkitTask t : new ArrayList<>(tasks)) t.cancel();
        tasks.clear();
    }

    private void preparePlayer(Player p, GameMode mode) {
        p.setGameMode(mode);
        p.getInventory().clear();
        for (PotionEffect ef : p.getActivePotionEffects()) p.removePotionEffect(ef.getType());
        p.setHealth(20.0);
        p.setFoodLevel(20);
        p.setFireTicks(0);
        p.setFallDistance(0);
    }

    // ------------------------------------------------------------ giris / cikis

    public void onJoin(Player p) {
        if (p.getGameMode() == GameMode.CREATIVE && p.hasPermission("lexeslaw.admin")) return;

        if (state == State.WAITING || state == State.COUNTDOWN) {
            preparePlayer(p, GameMode.ADVENTURE);
            p.teleport(arenaSpawn());
            broadcast("&a" + p.getName() + " &7oyuna katıldı &e(" + participants().size() + "/" + min() + ")");
            tryStartCountdown();
        } else {
            preparePlayer(p, GameMode.SPECTATOR);
            p.teleport(arenaSpawn());
            p.sendMessage(LexesLawFight.c("&cMaç devam ediyor, izleyici oldun."));
        }
    }

    public void onLeave(Player p) {
        if (p.getGameMode() == GameMode.SPECTATOR || p.getGameMode() == GameMode.ADVENTURE) {
            p.setGameMode(GameMode.SURVIVAL);
        }
        if (state == State.PREP || state == State.RUNNING) {
            UUID id = p.getUniqueId();
            boolean was = alive.remove(id);
            soldiers.remove(id);
            if (was) broadcast("&c" + p.getName() + " &7oyundan ayrıldı.");
            checkEnd();
        }
    }

    // ------------------------------------------------------------ baslatma

    private void tryStartCountdown() {
        if (state != State.WAITING) return;
        if (participants().size() < min()) return;
        state = State.COUNTDOWN;
        final int[] t = {plugin.getConfig().getInt("countdown-seconds", 30)};
        broadcast("&e" + min() + " oyuncu tamamlandı! Oyun &c" + t[0] + " &esaniye içinde başlıyor.");
        track(Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != State.COUNTDOWN) return;
            if (participants().size() < min()) {
                cancelTasks();
                state = State.WAITING;
                broadcast("&cYeterli oyuncu yok, geri sayım durduruldu.");
                return;
            }
            if (t[0] <= 0) {
                cancelTasks();
                startGame();
                return;
            }
            for (Player p : everyone()) p.sendActionBar(LexesLawFight.c("&eOyun başlıyor: &c" + t[0]));
            if (t[0] % 10 == 0 || t[0] <= 5) {
                broadcast("&7Oyun &c" + t[0] + " &7saniye içinde başlıyor...");
                soundAll(Sound.UI_BUTTON_CLICK, 0.7f, 1f);
            }
            t[0]--;
        }, 0L, 20L));
    }

    /** /startlaw */
    public void forceStart(CommandSender s) {
        if (state != State.WAITING && state != State.COUNTDOWN) {
            s.sendMessage(LexesLawFight.c("&cOyun zaten başladı."));
            return;
        }
        if (participants().size() < 2) {
            s.sendMessage(LexesLawFight.c("&cEn az 2 oyuncu gerekli."));
            return;
        }
        cancelTasks();
        startGame();
    }

    private void startGame() {
        List<Player> ps = participants();
        if (ps.size() < 2) {
            state = State.WAITING;
            return;
        }
        state = State.SELECTING;
        alive.clear();
        soldiers.clear();
        pendingSpectator.clear();
        captain = null;

        Player heroP = ps.get(rnd.nextInt(ps.size()));
        hero = heroP.getUniqueId();
        heroName = heroP.getName();
        roleIdx = rnd.nextInt(ROLES.length);
        armyIdx = rnd.nextInt(ARMIES.length);

        List<String> names = new ArrayList<>();
        for (Player p : ps) names.add(p.getName());

        broadcast("&6&l=== LAW FIGHT BAŞLIYOR ===");
        spin(names, heroName, "&7ANA KARAKTER", "&e", () ->
                spin(Arrays.asList(ROLES), ROLES[roleIdx], "&7ANA KARAKTERİN ROLÜ", "&b", () ->
                        spin(Arrays.asList(ARMIES), ARMIES[armyIdx], "&7KARŞISINDAKİ TAKIM", "&c",
                                this::beginPrep)));
    }

    /** Ekranda secenekler akar, 5 saniye sonra onceden secilen kazanan durur. */
    private void spin(List<String> options, String winner, String label, String color, Runnable done) {
        final int total = 100; // 5 saniye
        BukkitRunnable r = new BukkitRunnable() {
            int tick = 0;
            int next = 0;
            String last = "";

            @Override
            public void run() {
                if (state != State.SELECTING) { cancel(); return; }
                if (tick >= total) {
                    cancel();
                    for (Player p : everyone()) {
                        title(p, color + "&l" + winner, label, 0, 50, 10);
                        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
                    }
                    track(Bukkit.getScheduler().runTaskLater(plugin, done, 50L));
                    return;
                }
                if (tick >= next) {
                    String pick;
                    int guard = 0;
                    do {
                        pick = options.get(rnd.nextInt(options.size()));
                    } while (options.size() > 1 && pick.equals(last) && guard++ < 10);
                    last = pick;
                    for (Player p : everyone()) {
                        title(p, "&f" + pick, label, 0, 6, 0);
                        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
                    }
                    next = tick + (tick < 50 ? 2 : tick < 75 ? 4 : 6);
                }
                tick++;
            }
        };
        track(r.runTaskTimer(plugin, 0L, 1L));
    }

    private void beginPrep() {
        if (state != State.SELECTING) return;
        List<Player> ps = participants();
        Player heroP = hero == null ? null : Bukkit.getPlayer(hero);
        if (heroP == null || !heroP.getWorld().getName().equals(worldName) || ps.size() < 2
                || !ps.contains(heroP)) {
            abort("&cOyun iptal edildi (oyuncu ayrıldı).");
            return;
        }

        List<Player> army = new ArrayList<>(ps);
        army.remove(heroP);
        Player cap = army.get(rnd.nextInt(army.size()));
        captain = cap.getUniqueId();

        alive.clear();
        soldiers.clear();
        alive.add(hero);
        for (Player p : army) {
            alive.add(p.getUniqueId());
            soldiers.add(p.getUniqueId());
        }

        String armyName = ARMIES[armyIdx];
        String role = ROLES[roleIdx];
        boolean capEnds = plugin.getConfig().getBoolean("captain-death-ends-game", true);

        setup(heroP, heroSpawn(), "hero_" + ROLE_KEYS[roleIdx]);
        title(heroP, "&6&lANA KARAKTERSİN", "&e" + role + " &7• 1v" + army.size(), 5, 60, 10);
        heroP.sendMessage(LexesLawFight.c("&6Rolün: &e" + role + "&6. Karşındaki takım: &c" + armyName
                + " &7(" + army.size() + " kişi)"));

        for (Player p : army) {
            boolean isCap = p.getUniqueId().equals(captain);
            setup(p, armySpawn(), (isCap ? "cap_" : "team_") + ARMY_KEYS[armyIdx]);
            title(p, "&c&l" + armyName, "&7Ana karakteri öldür!", 5, 60, 10);
            p.sendMessage(LexesLawFight.c("&cTakımın: &f" + armyName + "&c. Ana karakter: &e" + heroName
                    + " &7(" + role + ")&c. Kaptanınız: &6" + cap.getName()));
            if (isCap) {
                title(p, "&6&lKAPTANSIN!", capEnds ? "&7Sen ölürsen oyun biter!" : "&7Takımını yönet!", 5, 60, 10);
            }
        }

        state = State.PREP;
        broadcast("&a" + plugin.getConfig().getInt("prep-seconds", 10)
                + " saniye PvP kapalı! &7Envanterini düzenle.");
        final int[] t = {plugin.getConfig().getInt("prep-seconds", 10)};
        track(Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state != State.PREP) return;
            if (t[0] <= 0) {
                cancelTasks();
                startFight();
                return;
            }
            for (Player p : everyone()) {
                p.sendActionBar(LexesLawFight.c("&aPvP kapalı &7- envanterini düzenle &8| &eSavaş &c" + t[0] + " &esn sonra"));
                if (t[0] <= 3) {
                    title(p, "&c" + t[0], "", 0, 20, 0);
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1f);
                }
            }
            t[0]--;
        }, 20L, 20L));
    }

    private void setup(Player p, Location loc, String kitKey) {
        preparePlayer(p, GameMode.SURVIVAL);
        p.teleport(loc);
        if (!plugin.giveKit(p, kitKey)) {
            p.sendMessage(LexesLawFight.c("&cBu kit henüz ayarlanmamış: &e" + kitKey + " &7(admine söyle)"));
            plugin.getLogger().warning("Kit ayarlanmamis: " + kitKey);
        }
    }

    private void startFight() {
        state = State.RUNNING;
        titleAll("&c&lSAVAŞ BAŞLADI!", "", 0, 40, 10);
        soundAll(Sound.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 1f);
        broadcast("&c&l⚔ SAVAŞ BAŞLADI! PvP açık! ⚔");
    }

    private void abort(String reason) {
        cancelTasks();
        broadcast(reason);
        alive.clear();
        soldiers.clear();
        pendingSpectator.clear();
        hero = null;
        captain = null;
        state = State.WAITING;
        for (Player p : participants()) preparePlayer(p, GameMode.ADVENTURE);
        tryStartCountdown();
    }

    // ------------------------------------------------------------ olum

    public void eliminate(Player p, Player killer, boolean dead) {
        UUID id = p.getUniqueId();
        if (!alive.remove(id)) return;
        soldiers.remove(id);

        String who = id.equals(hero) ? "&6ANA KARAKTER &e" + p.getName() : "&c" + p.getName();
        String by = (killer != null && killer != p) ? " &7— &f" + killer.getName() + " &7öldürdü" : "";
        broadcast("&c☠ " + who + " &7öldü." + by + " &8| &7Kalan asker: &f" + soldiers.size());

        if (dead) pendingSpectator.add(id);
        else toSpectator(p);
        checkEnd();
    }

    /** Oyuncuyu izleyici yapar ve kirmizi "OLDUN!" yazisini gosterir. */
    public void toSpectator(Player p) {
        preparePlayer(p, GameMode.SPECTATOR);
        title(p, "&c&lÖLDÜN!", "&7Maçı izleyebilirsin", 0, 60, 20);
        p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.4f, 1f);
    }

    private void checkEnd() {
        if (state != State.RUNNING && state != State.PREP) return;
        if (hero == null) return;
        if (!alive.contains(hero)) {
            endGame(false);
            return;
        }
        boolean capEnds = plugin.getConfig().getBoolean("captain-death-ends-game", true);
        if (soldiers.isEmpty() || (capEnds && captain != null && !soldiers.contains(captain))) {
            endGame(true);
        }
    }

    // ------------------------------------------------------------ bitis

    private void endGame(boolean heroWins) {
        state = State.ENDING;
        cancelTasks();

        String chat, main, sub;
        if (heroWins) {
            chat = "&6&l★ ANA KARAKTER KAZANDI!! ★ &e" + heroName + " &7(" + ROLES[roleIdx] + ")";
            main = "&6&lANA KARAKTER";
            sub = "&e&lKAZANDI!!";
        } else {
            chat = "&c&l★ " + ARMIES[armyIdx] + " TAKIMI KAZANDI!!! ★";
            main = "&c&l" + ARMIES[armyIdx] + " TAKIMI";
            sub = "&6&lKAZANDI!!!";
        }
        broadcast(chat);
        titleAll(main, sub, 10, 120, 20);

        // havai fisek sesi + gorseli
        final int[] n = {0};
        track(Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (n[0]++ >= 24) return;
            List<Player> ps = everyone();
            for (Player p : ps) {
                Sound s = rnd.nextBoolean() ? Sound.ENTITY_FIREWORK_ROCKET_LAUNCH : Sound.ENTITY_FIREWORK_ROCKET_BLAST;
                p.playSound(p.getLocation(), s, 1f, 0.9f + rnd.nextFloat() * 0.3f);
                if (rnd.nextInt(4) == 0) p.playSound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1f, 1f);
            }
            if (!ps.isEmpty()) {
                Player p = ps.get(rnd.nextInt(ps.size()));
                spawnFirework(p.getLocation().add(rnd.nextInt(9) - 4, 3, rnd.nextInt(9) - 4));
            }
        }, 0L, 6L));

        long delay = plugin.getConfig().getInt("end-delay-seconds", 8) * 20L;
        track(Bukkit.getScheduler().runTaskLater(plugin, this::finish, delay));
    }

    private void spawnFirework(Location l) {
        if (l.getWorld() == null) return;
        Firework fw = l.getWorld().spawn(l, Firework.class);
        FireworkMeta m = fw.getFireworkMeta();
        Color[] cols = {Color.RED, Color.YELLOW, Color.ORANGE, Color.LIME, Color.AQUA, Color.FUCHSIA};
        m.addEffect(FireworkEffect.builder().with(FireworkEffect.Type.BALL_LARGE)
                .withColor(cols[rnd.nextInt(cols.length)], cols[rnd.nextInt(cols.length)])
                .withFade(Color.WHITE).flicker(true).build());
        fw.setFireworkMeta(m);
        fw.detonate();
    }

    /** Herkesi lobiye (NPC'nin oldugu yer) atar ve arenayi sifirlar. */
    private void finish() {
        cancelTasks();
        Location lobby = plugin.getLobby();
        boolean sameWorld = lobby.getWorld() != null && lobby.getWorld().getName().equals(worldName);
        for (Player p : everyone()) {
            preparePlayer(p, GameMode.SURVIVAL);
            if (!sameWorld) p.teleport(lobby);
        }
        alive.clear();
        soldiers.clear();
        pendingSpectator.clear();
        hero = null;
        captain = null;
        state = State.WAITING;
        if (sameWorld) for (Player p : everyone()) onJoin(p);
    }

    /** /stoplaw */
    public void stop() {
        cancelTasks();
        broadcast("&cOyun admin tarafından durduruldu.");
        finish();
    }
}
