package com.lexes.lawfight;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.*;

/** /spaw (lobi) dunyasinin scoreboard'u. Baslik, IP ve renkler asagidaki sabitlerden degistirilir. */
public class LobbyBoard {

    // ---- AYARLAR (buradan degistir) ----
    static final String TITLE = "§9§lLexes NW";      // baslik (§ ile renk kodu)
    static final String IP = "&7lexesnw.mcsh.gg";     // en alt satir (& ile renk kodu)
    static final String COLOR_LABEL = "&9";           // "Oyuncu:" etiketi rengi
    static final String COLOR_VALUE = "&f";           // sayi ve isim rengi
    // ------------------------------------

    private final LexesLawFight plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    public LobbyBoard(LexesLawFight plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, this::update, 20L, 20L);
    }

    private World lobbyWorld() {
        Location l = plugin.getLobby();
        return l == null ? null : l.getWorld();
    }

    private Scoreboard newBoard() {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective ob = sb.registerNewObjective("lexesnw", Criteria.DUMMY, TITLE);
        ob.setDisplaySlot(DisplaySlot.SIDEBAR);
        return sb;
    }

    private void update() {
        World w = lobbyWorld();
        if (w == null) return;

        // lobiden cikanlarin bizim panosunu ana panoya geri ver (arena panosuna dokunma)
        for (UUID id : new ArrayList<>(boards.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || p.getWorld() != w) {
                Scoreboard mine = boards.remove(id);
                if (p != null && p.getScoreboard() == mine) {
                    p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
                }
            }
        }

        int online = Bukkit.getOnlinePlayers().size();
        for (Player p : new ArrayList<>(w.getPlayers())) {
            Scoreboard sb = boards.computeIfAbsent(p.getUniqueId(), k -> newBoard());
            if (p.getScoreboard() != sb) p.setScoreboard(sb);
            Objective ob = sb.getObjective("lexesnw");
            if (ob == null) continue;

            for (String e : new ArrayList<>(sb.getEntries())) sb.resetScores(e);

            List<String> lines = List.of(
                    COLOR_VALUE + p.getName(),
                    "&r ",
                    COLOR_LABEL + "Oyuncu: " + COLOR_VALUE + online,
                    "&r  ",
                    IP
            );
            for (int i = 0; i < lines.size(); i++) {
                ob.getScore(lines.get(i).replace('&', '§')).setScore(lines.size() - i);
            }
        }
    }
}
