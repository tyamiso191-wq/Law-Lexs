Bu klasördeki jar'lar sunucunun plugins klasörüne kopyalanacak.

Sunucuya atılacaklar:
  - LexesLawFight-1.0.jar (GitHub Actions ile derlenen, bizim plugin)
  - Citizens-2.0.44.jar
  - Sentinel-2.9.4-SNAPSHOT.jar
  - FancyNpcs-2.12.1.jar
  - Multiverse-Core (ayrıca, bu pakette yok)

Eski Citizens/Sentinel/FancyNpcs jar'larını plugins klasöründen silmeyi unutma.
