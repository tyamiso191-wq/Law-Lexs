package com.lexes.lawfight;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;

/** Lobi dunyalari: mob dogmaz, adminler haric blok koyulamaz/kirilamaz. */
public class LobbyListener implements Listener {

    private final LexesLawFight plugin;

    public LobbyListener(LexesLawFight plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onSpawn(CreatureSpawnEvent e) {
        if (!plugin.isLobbyWorld(e.getLocation().getWorld())) return;
        // Plugin/komutla yapilan dogumlara (CUSTOM, COMMAND) izin ver, dogal ve yumurta dogumlarini engelle
        switch (e.getSpawnReason()) {
            case CUSTOM, COMMAND -> { }
            default -> e.setCancelled(true);
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (!plugin.isLobbyWorld(e.getBlock().getWorld())) return;
        if (isAdmin(e.getPlayer())) return;
        e.setCancelled(true);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (!plugin.isLobbyWorld(e.getBlock().getWorld())) return;
        if (isAdmin(e.getPlayer())) return;
        e.setCancelled(true);
    }

    private boolean isAdmin(Player p) {
        return p.hasPermission("lexeslaw.admin");
    }
}
