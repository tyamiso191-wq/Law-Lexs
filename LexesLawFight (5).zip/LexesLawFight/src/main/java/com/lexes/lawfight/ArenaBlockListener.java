package com.lexes.lawfight;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

/** Arena blok modu: herkes koyabilir, kirma sadece oyuncularin kendi koydugu bloklarla sinirli. */
public class ArenaBlockListener implements Listener {

    private final LexesLawFight plugin;

    public ArenaBlockListener(LexesLawFight plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (!plugin.isArenaBlockWorld(e.getBlock().getWorld())) return;
        if (isAdmin(e.getPlayer())) return;
        plugin.trackPlaced(e.getBlock());
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (!plugin.isArenaBlockWorld(e.getBlock().getWorld())) return;
        if (isAdmin(e.getPlayer())) return;
        if (plugin.takePlaced(e.getBlock())) return; // oyuncunun koydugu blok: kirilabilir
        e.setCancelled(true);
    }

    private boolean isAdmin(Player p) {
        return p.hasPermission("lexeslaw.admin");
    }
}
