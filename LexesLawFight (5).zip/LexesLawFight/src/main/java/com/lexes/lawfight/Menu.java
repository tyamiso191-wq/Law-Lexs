package com.lexes.lawfight;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class Menu implements Listener {

    private static final int[] SLOTS = {12, 13, 14};
    private final LexesLawFight plugin;

    public Menu(LexesLawFight plugin) {
        this.plugin = plugin;
    }

    static class Holder implements InventoryHolder {
        Inventory inv;
        @Override
        public Inventory getInventory() { return inv; }
    }

    public static void open(LexesLawFight pl, Player p) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("Law Fight"));
        h.inv = inv;

        ItemStack glass = new ItemStack(Material.LIGHT_GRAY_STAINED_GLASS_PANE);
        ItemMeta gm = glass.getItemMeta();
        gm.displayName(Component.text(" "));
        glass.setItemMeta(gm);
        for (int i = 0; i < 27; i++) inv.setItem(i, glass);

        for (int i = 0; i < 3; i++) inv.setItem(SLOTS[i], area(pl, i + 1));
        p.openInventory(inv);
    }

    private static ItemStack area(LexesLawFight pl, int n) {
        ItemStack it = new ItemStack(Material.GRASS_BLOCK);
        ItemMeta m = it.getItemMeta();
        m.displayName(LexesLawFight.c("&a&lArea " + n).decoration(TextDecoration.ITALIC, false));

        String worldName = "area" + n;
        World w = Bukkit.getWorld(worldName);
        Game g = pl.getGame(worldName);
        String status;
        int count = 0;
        if (g == null) {
            status = "&cHazır değil";
        } else {
            if (w != null) count = w.getPlayers().size();
            Game.State st = g.getState();
            status = (st == Game.State.WAITING || st == Game.State.COUNTDOWN) ? "&aBekliyor" : "&cOyunda";
        }
        List<Component> lore = new ArrayList<>();
        lore.add(LexesLawFight.c("&7Oyuncu: &f" + count).decoration(TextDecoration.ITALIC, false));
        lore.add(LexesLawFight.c("&7Durum: " + status).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text(" "));
        lore.add(LexesLawFight.c("&eTıkla ve katıl!").decoration(TextDecoration.ITALIC, false));
        m.lore(lore);
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;

        int n = 0;
        for (int i = 0; i < 3; i++) if (e.getSlot() == SLOTS[i]) n = i + 1;
        if (n == 0) return;

        p.closeInventory();
        World w = plugin.loadWorld("area" + n);
        if (w == null || plugin.getGame(w) == null) {
            p.sendMessage(LexesLawFight.c("&cArea " + n + " henüz hazır değil."));
            return;
        }
        Location spawn = plugin.getLoc("spawn." + w.getName());
        if (spawn == null) spawn = w.getSpawnLocation();
        p.teleport(spawn);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
