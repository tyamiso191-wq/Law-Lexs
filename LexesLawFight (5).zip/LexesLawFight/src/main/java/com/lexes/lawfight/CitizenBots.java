package com.lexes.lawfight;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Mob;
import org.bukkit.inventory.ItemStack;

import java.lang.reflect.Method;

/**
 * Citizens + Sentinel botlari. Derleme sirasinda bu pluginlere bagli degildir;
 * sadece calisma aninda, ikisi de kuruluysa kullanilir.
 * Herhangi bir adim basarisiz olursa null doner, Game Husk botlarina duser.
 */
public final class CitizenBots {

    private CitizenBots() {}

    public static boolean available() {
        var pm = Bukkit.getPluginManager();
        var c = pm.getPlugin("Citizens");
        var s = pm.getPlugin("Sentinel");
        // kurulu olmak yetmez, acik (enabled) olmalilar; aksi halde Husk'a dus
        return c != null && c.isEnabled() && s != null && s.isEnabled();
    }

    /** Citizens NPC'si olusturur (Husk tipinde), Sentinel ekler, spawn eder. */
    public static Object spawnNpc(Location loc, String name, ItemStack[] kit) {
        try {
            Class<?> apiC = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = apiC.getMethod("getNPCRegistry").invoke(null);
            Class<?> regC = Class.forName("net.citizensnpcs.api.npc.NPCRegistry");
            Object npc = regC.getMethod("createNPC", EntityType.class, String.class)
                    .invoke(registry, EntityType.HUSK, name);

            Class<?> npcC = Class.forName("net.citizensnpcs.api.npc.NPC");
            npcC.getMethod("spawn", Location.class).invoke(npc, loc);

            // Sentinel trait'i ekle. Hedef olarak "players" VERILMEZ: tum oyunculara saldirmasinlar.
            // Ana karaktere yonlendirme Game.steerBots ile yapilir.
            try {
                Class<?> sentC = Class.forName("org.mcmonkey.sentinel.SentinelTrait");
                npcC.getMethod("getOrAddTrait", Class.class).invoke(npc, sentC);
            } catch (Exception ex) {
                Bukkit.getLogger().warning("[LexesLawFight] Sentinel bulunamadi: " + ex);
            }
            return npc;
        } catch (Exception ex) {
            Bukkit.getLogger().warning("[LexesLawFight] Citizens bot olusturulamadi: " + ex);
            return null;
        }
    }

    /** NPC'nin canli varligini (Mob) doner. */
    public static Mob entityOf(Object npc) {
        try {
            Class<?> npcC = Class.forName("net.citizensnpcs.api.npc.NPC");
            Object e = npcC.getMethod("getEntity").invoke(npc);
            return (e instanceof Mob m) ? m : null;
        } catch (Exception ex) {
            return null;
        }
    }

    public static void destroy(Object npc) {
        try {
            Class<?> npcC = Class.forName("net.citizensnpcs.api.npc.NPC");
            Method m = npcC.getMethod("destroy");
            m.invoke(npc);
        } catch (Exception ignored) {
        }
    }
}
