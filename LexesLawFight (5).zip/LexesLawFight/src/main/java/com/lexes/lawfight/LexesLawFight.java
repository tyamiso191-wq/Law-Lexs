package com.lexes.lawfight;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class LexesLawFight extends JavaPlugin implements TabExecutor {

    private static final Map<String, String> HEROES = Map.of(
            "kitmisoty", "misoty",
            "kitflame", "flame",
            "kitwemmbu", "wemmbu",
            "kitpear", "pear");

    private static final Map<String, String> TEAMS = Map.of(
            "kitlaw", "law",
            "kitmafia", "mafia",
            "kitcindercrest", "cindercrest",
            "kitnortherncouncil", "northerncouncil");

    private File kitFile, dataFile;
    private YamlConfiguration kits, data;
    private final Set<String> worldSet = new HashSet<>();
    private final Set<String> lobbyWorlds = new HashSet<>();
    private final Set<String> arenaBlockWorlds = new HashSet<>();
    private final Set<String> placedKeys = new HashSet<>();   // oyuncularin koydugu bloklar: dunya:x:y:z
    private final Map<String, Game> games = new HashMap<>();

    public static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getDataFolder().mkdirs();
        kitFile = new File(getDataFolder(), "kits.yml");
        dataFile = new File(getDataFolder(), "data.yml");
        kits = YamlConfiguration.loadConfiguration(kitFile);
        data = YamlConfiguration.loadConfiguration(dataFile);
        worldSet.addAll(data.getStringList("worlds"));
        lobbyWorlds.addAll(data.getStringList("lobby-worlds"));
        arenaBlockWorlds.addAll(data.getStringList("arena-block-worlds"));

        for (String name : getDescription().getCommands().keySet()) {
            PluginCommand pc = getCommand(name);
            if (pc != null) {
                pc.setExecutor(this);
                pc.setTabCompleter(this);
            }
        }
        getServer().getPluginManager().registerEvents(new GameListener(this), this);
        getServer().getPluginManager().registerEvents(new Menu(this), this);
        getServer().getPluginManager().registerEvents(new LobbyListener(this), this);
        getServer().getPluginManager().registerEvents(new ArenaBlockListener(this), this);
        getLogger().info("Lexes Law Fight aktif.");
    }

    @Override
    public void onDisable() {
        for (Game g : games.values()) g.cancelTasks();
    }

    // ------------------------------------------------------------ veri

    private void saveData() {
        try { data.save(dataFile); } catch (IOException e) { getLogger().severe(e.getMessage()); }
    }

    private void saveKits() {
        try { kits.save(kitFile); } catch (IOException e) { getLogger().severe(e.getMessage()); }
    }

    public void saveLoc(String path, Location l) {
        data.set(path + ".world", l.getWorld().getName());
        data.set(path + ".x", l.getX());
        data.set(path + ".y", l.getY());
        data.set(path + ".z", l.getZ());
        data.set(path + ".yaw", (double) l.getYaw());
        data.set(path + ".pitch", (double) l.getPitch());
        saveData();
    }

    public Location getLoc(String path) {
        String wn = data.getString(path + ".world");
        if (wn == null) return null;
        World w = loadWorld(wn);
        if (w == null) return null;
        return new Location(w, data.getDouble(path + ".x"), data.getDouble(path + ".y"),
                data.getDouble(path + ".z"), (float) data.getDouble(path + ".yaw"),
                (float) data.getDouble(path + ".pitch"));
    }

    public World loadWorld(String name) {
        World w = Bukkit.getWorld(name);
        if (w == null && new File(Bukkit.getWorldContainer(), name).isDirectory()) {
            w = Bukkit.createWorld(new WorldCreator(name));
        }
        return w;
    }

    public Location getLobby() {
        Location l = getLoc("lobby");
        return l != null ? l : Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    public Game getGame(String worldName) {
        if (!worldSet.contains(worldName)) return null;
        return games.computeIfAbsent(worldName, n -> new Game(this, n));
    }

    public Game getGame(World w) {
        return w == null ? null : getGame(w.getName());
    }

    public boolean isArenaBlockWorld(World w) {
        return w != null && arenaBlockWorlds.contains(w.getName());
    }

    private static String key(Block b) {
        return b.getWorld().getName() + ":" + b.getX() + ":" + b.getY() + ":" + b.getZ();
    }

    public void trackPlaced(Block b) { placedKeys.add(key(b)); }

    /** Blok oyuncunun koydugu bir blok mu; oyleyse kaydi siler ve true doner. */
    public boolean takePlaced(Block b) { return placedKeys.remove(key(b)); }

    /** Mac bitince: oyuncularin koydugu bloklari siler, dunyadaki yerdeki esyalari temizler. */
    public void cleanupArena(String worldName) {
        World w = Bukkit.getWorld(worldName);
        String prefix = worldName + ":";
        Iterator<String> it = placedKeys.iterator();
        while (it.hasNext()) {
            String k = it.next();
            if (!k.startsWith(prefix)) continue;
            it.remove();
            if (w == null) continue;
            String[] a = k.substring(prefix.length()).split(":");
            w.getBlockAt(Integer.parseInt(a[0]), Integer.parseInt(a[1]), Integer.parseInt(a[2]))
                    .setType(Material.AIR, false);
        }
        if (w != null && isArenaBlockWorld(w)) {
            for (Item i : w.getEntitiesByClass(Item.class)) i.remove();
        }
    }

    public boolean isLobbyWorld(World w) {
        return w != null && lobbyWorlds.contains(w.getName());
    }

    public Collection<Game> allGames() {
        return games.values();
    }

    // ------------------------------------------------------------ kit

    private void saveKit(String key, Player p) {
        kits.set("kits." + key, Arrays.asList(p.getInventory().getContents()));
        saveKits();
    }

    /** Oyuncunun envanterini temizler ve kiti verir. Kit yoksa false doner. */
    public boolean giveKit(Player p, String key) {
        List<?> list = kits.getList("kits." + key);
        if (list == null) return false;
        ItemStack[] items = new ItemStack[list.size()];
        for (int i = 0; i < items.length; i++) {
            Object o = list.get(i);
            items[i] = (o instanceof ItemStack is) ? is : null;
        }
        p.getInventory().clear();
        p.getInventory().setContents(items);
        p.updateInventory();
        return true;
    }

    /** Kit icerigini dizi olarak doner (yoksa null). */
    public ItemStack[] getKit(String key) {
        List<?> list = kits.getList("kits." + key);
        if (list == null) return null;
        ItemStack[] items = new ItemStack[list.size()];
        for (int i = 0; i < items.length; i++) {
            Object o = list.get(i);
            items[i] = (o instanceof ItemStack is) ? is : null;
        }
        return items;
    }

    // ------------------------------------------------------------ komutlar

    @Override
    public boolean onCommand(CommandSender s, Command command, String label, String[] a) {
        String cmd = command.getName().toLowerCase();

        if (cmd.equals("lobi")) {
            if (!(s instanceof Player p)) return true;
            Game g = getGame(p.getWorld());
            if (g != null && g.isInActiveMatch(p)) {
                p.sendMessage(c("&cMaç sırasında lobiye dönemezsin."));
                return true;
            }
            p.teleport(getLobby());
            p.sendMessage(c("&aSpawn'a ışınlandın."));
            return true;
        }
        if (cmd.equals("lawmenu")) {
            if (s instanceof Player p) Menu.open(this, p);
            return true;
        }
        if (!s.hasPermission("lexeslaw.admin")) {
            s.sendMessage(c("&cBu komutu kullanma yetkin yok."));
            return true;
        }

        if (cmd.equals("startlaw") || cmd.equals("stoplaw")) {
            World w = null;
            if (a.length > 0) w = Bukkit.getWorld(a[0]);
            else if (s instanceof Player p) w = p.getWorld();
            Game g = getGame(w);
            if (g == null) {
                s.sendMessage(c("&cBu dünya Law Fight dünyası değil. Dünyada &e/lawworld &cyaz."));
                return true;
            }
            if (cmd.equals("startlaw")) g.forceStart(s);
            else { g.stop(); s.sendMessage(c("&aOyun durduruldu.")); }
            return true;
        }

        if (!(s instanceof Player p)) {
            s.sendMessage("Bu komutu sadece oyuncular kullanabilir.");
            return true;
        }

        switch (cmd) {
            case "lawworld" -> {
                String n = p.getWorld().getName();
                if (worldSet.add(n)) {
                    data.set("worlds", new ArrayList<>(worldSet));
                    saveData();
                    p.sendMessage(c("&a" + n + " &7artık &6Law Fight &7dünyası!"));
                } else {
                    p.sendMessage(c("&e" + n + " zaten Law Fight dünyası."));
                }
                return true;
            }
            case "spaw" -> {
                saveLoc("lobby", p.getLocation());
                p.sendMessage(c("&aSunucu spawn noktası ayarlandı: bulunduğun yer. "
                        + "&7(Girişte, ölünce ve oyun bitince herkes buraya gelir)"));
                return true;
            }
            case "lawspawn" -> {
                saveLoc("spawn." + p.getWorld().getName(), p.getLocation());
                p.sendMessage(c("&aArena doğma noktası ayarlandı."));
                return true;
            }
            case "anak" -> {
                saveLoc("hero." + p.getWorld().getName(), p.getLocation());
                p.sendMessage(c("&aAna karakter doğma noktası ayarlandı: bulunduğun yer."));
                return true;
            }
            case "teamsp" -> {
                saveLoc("army." + p.getWorld().getName(), p.getLocation());
                p.sendMessage(c("&aTakım doğma noktası ayarlandı: bulunduğun yer."));
                return true;
            }
            case "lawnpc" -> {
                if (getLoc("lobby") == null) {
                    saveLoc("lobby", p.getLocation());
                    p.sendMessage(c("&aSpawn henüz ayarlı değildi, burası spawn yapıldı. (/spaw ile değiştir)"));
                }
                if (Bukkit.getPluginManager().getPlugin("FancyNpcs") == null) {
                    p.sendMessage(c("&cFancyNpcs kurulu değil, NPC oluşturulamadı."));
                    return true;
                }
                String name = getConfig().getString("npc.name", "lawfight");
                for (String raw : getConfig().getStringList("npc.commands")) {
                    Bukkit.dispatchCommand(p, raw.replace("{name}", name));
                }
                p.sendMessage(c("&aLaw Fight NPC'si oluşturuldu."));
                return true;
            }
            case "arenablok" -> {
                String n = p.getWorld().getName();
                if (arenaBlockWorlds.remove(n)) {
                    p.sendMessage(c("&e" + n + " &7için arena blok modu kapandı."));
                } else {
                    arenaBlockWorlds.add(n);
                    p.sendMessage(c("&a" + n + " &7için arena blok modu açıldı: oyuncular sadece koyabilir, kendi koydukları blokları kırabilir."));
                }
                data.set("arena-block-worlds", new ArrayList<>(arenaBlockWorlds));
                saveData();
                return true;
            }
            case "lobworld" -> {
                String n = p.getWorld().getName();
                if (lobbyWorlds.remove(n)) {
                    p.sendMessage(c("&e" + n + " &7artık lobi değil (koruma kapandı)."));
                } else {
                    lobbyWorlds.add(n);
                    p.sendMessage(c("&a" + n + " &7artık lobi: mob doğmaz, adminler dışında blok koyulamaz/kırılamaz."));
                }
                data.set("lobby-worlds", new ArrayList<>(lobbyWorlds));
                saveData();
                return true;
            }
            default -> { }
        }

        // kit komutlari
        String key, display;
        if (HEROES.containsKey(cmd)) {
            key = "hero_" + HEROES.get(cmd);
            display = HEROES.get(cmd) + " (ana karakter)";
        } else if (TEAMS.containsKey(cmd)) {
            boolean cap = a.length > 0 && a[0].equalsIgnoreCase("cap");
            key = (cap ? "cap_" : "team_") + TEAMS.get(cmd);
            display = TEAMS.get(cmd) + (cap ? " kaptan kiti" : " takım kiti");
        } else {
            return false;
        }
        saveKit(key, p);
        p.sendMessage(c("&aKit kaydedildi: &6" + display));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1 && TEAMS.containsKey(c.getName().toLowerCase())
                && "cap".startsWith(a[0].toLowerCase())) {
            return List.of("cap");
        }
        return Collections.emptyList();
    }
}
