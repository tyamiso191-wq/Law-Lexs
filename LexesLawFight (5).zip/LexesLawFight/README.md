# Lexes Law Fight (Paper 1.21.x + FancyNpcs)

## Kurulum
1. Sunucuya **Paper 1.21.x** ve **FancyNpcs** kur.
2. Bu projeyi derle: `mvn package` -> `target/LexesLawFight-1.0.jar` (plugins klasorune at).
   Bilgisayarin yoksa projeyi GitHub'a yukle, "Actions" sekmesinde Build calisinca jar'i indir.
3. Dunyalari hazirla: `area1`, `area2`, `area3` adinda 3 dunya (Multiverse vb. ile).
4. Her arena dunyasinda: `/lawworld`, `/lawspawn` (ve istege bagli `/lawhero`, `/lawarmy`).
5. Lobide NPC'yi koymak istedigin yerde: `/lawnpc`.
6. 12 kiti ayarla (asagida).

## Komutlar (hepsi sadece admin: lexeslaw.admin)
| Komut | Ne yapar |
|---|---|
| /spaw | Bulundugun yeri sunucu spawn'i yapar: sunucuya her girdiginde, olunce ve Law Fight bitince herkes burada dogar |
| /lawnpc | Lobiyi (oyun bitince herkesin gidecegi yer) ayarlar, bulundugun yerde sana bakan yone bakan, her oyuncuya kendi skinini gosteren Law Fight NPC'sini olusturur |
| /lawworld | Bulundugun dunyayi Law Fight arena dunyasi yapar |
| /lawspawn | Bulundugun dunyada menuden gelenlerin dogacagi bekleme noktasini ayarlar |
| /anak | Bulundugun yeri ana karakterin doguş noktasi yapar (yoksa /lawspawn) |
| /teamsp | Bulundugun yeri takimin dogus noktasi yapar (yoksa /lawspawn) |
| /startlaw [dunya] | 8 kisiyi beklemeden oyunu aninda baslatir (en az 2 oyuncu) |
| /stoplaw [dunya] | Oyunu durdurur, herkesi lobiye atar |
| /kitmisoty /kitflame /kitwemmbu /kitpear | Envanterini ana karakter kiti olarak kaydeder |
| /kitlaw /kitmafia /kitcindercrest /kitnortherncouncil | Envanterini o takimdaki herkese verilecek kit olarak kaydeder |
| /kitlaw cap  /kitmafia cap  /kitcindercrest cap  /kitnortherncouncil cap | Envanterini o takimin kaptan kiti olarak kaydeder |
| /lawmenu | Law Fight menusunu acar (NPC sag tiklaninca bunu calistirir) |

Kit komutlari sadece kaydeder; kitler oyun baslayinca otomatik verilir.

Oyun baslayinca ilk 10 saniye PvP kapalidir (envanter duzenleme icin), sonra savas baslar.
